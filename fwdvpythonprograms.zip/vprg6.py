import matplotlib.pyplot as plt;
x=[2,4,6,8,10]
y=[6,7,8,2,4]
plt.bar(x,y)
plt.xlabel('x')
plt.ylabel('y')
plt.show()


