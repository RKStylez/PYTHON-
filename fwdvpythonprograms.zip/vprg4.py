#gcurve, gdots, gvbars, or ghbars
from visual import *
from visual.graph import *
ch=input('1.Sin(x)\n2.Cos(x)\nEnter Your Choice: ')
if(ch==1):
    gdisplay(title='sin(x)',xtitle='x', ytitle='sin(x)',foreground=color.yellow, background=color.black)
    f1 = gdots(color=color.cyan) # a graphics curve
    for x in arange(0, 8.05, 0.1): # x goes from 0 to 8
        y=sin(x)
        f1.plot(pos=(x,y))
if(ch==2):
    gdisplay(title='cos(x)',xtitle='x', ytitle='cos(x)',foreground=color.yellow, background=color.black)
    f1 = gcurve(color=color.red) # a graphics curve
    for x in arange(0, 8.05, 0.1): # x goes from 0 to 8
        y=cos(x)*exp(-0.2*x)
        f1.plot(pos=(x,y))
