from tkinter import *
import tkinter  as tk
from functools import partial
from tkinter import ttk
from tkinter import messagebox

def show_msg():
        if(username.get()=="" and password.get()==""):
                messagebox.showerror ("Error ",'\n \a Blank not allow') 
        elif(username.get()==""):
                messagebox.showinfo ("Error ",'\a please Enter username') 
        elif(password.get()==""):
                messagebox.showinfo ("Error ",'\a please Enter password') 
        elif(username.get()=="dhurai05" and password.get()=="1234"):
                messagebox.showinfo ("Success ",'\a Login Successful') 
        else :
                messagebox.showerror ("Oops ",'\ainvalid username/password') 

def validateLogin(username, password):
	print("username entered :", username.get())
	print("password entered :", password.get())
	return
#window
dhurai = Tk()  
dhurai.geometry('300x150')  
dhurai.title('Kabaddi notice Login Form')
dhurai.configure(bg='light blue')

dhurai = tk.Canvas(dhurai,width=35,height=15,bg='light blue')
dhurai.pack()
dhurai.create_text(175,40,fill='#c0c0c0',font="Times 15  bold",text="Welcome to Kabaddi Notice.com")


#username label and text entry box
usernameLabel = Label(dhurai, text="User Name",bg='light blue', fg='black').grid(row=0, column=0)
username = StringVar()
usernameEntry = Entry(dhurai, textvariable=username).grid(row=0, column=1)  

#password label and password entry box
passwordLabel = Label(dhurai,text="Password",bg='light blue', fg='black').grid(row=1, column=0)  
password = StringVar()
passwordEntry = Entry(dhurai, textvariable=password, show='*').grid(row=1, column=1)  

validateLogin = partial(validateLogin, username, password)

#login button
ttk.Button = Button(dhurai, text="Login", bg='red', fg='black',command=show_msg).grid(row=7, column=10)  
dhurai.mainloop()
