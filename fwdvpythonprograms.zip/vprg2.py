import numpy as np
import scipy
from scipy import special
import matplotlib.pyplot as plt
x = np.linspace(0, 10, 100)
fig, ax = plt.subplots()
for n in range(4):
 ax.plot(x, scipy.special.jn(n, x),
label=r"$J_%d(x)$" % n)
ax.legend()
