#https://www.glowscript.org/docs/VPythonDocs/primitives.html, https://www.vpython.org/contents/docs/materials.html
from visual import *
#curve(pos=[(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,-1)],radius=0.1,color=color.magenta)
#arrow(pos=[0,-1,1],axis=(0,-5,0),shaftwidth=0.5,color=color.red)
#box(pos=(5,0,0),material=materials.marble,height=5,widht=5,color=color.blue)
#cone(pos=[0,-1,1],axis=(0,-5,0),radius=1,color=color.red)
#cylinder(pos=[0,-5,0],axis=(0,-5,0),radius=1,color=color.red)
#helix(pos=[0,-5,0],axis=(0,-5,0),radius=1,color=color.red)
#ellipsoid(pos=(0,0,0),material=materials.marble,height=2,widht=5,color=color.blue)
#points(pos=[0,0,-1],radius=50,color=color.red)

#rectangular base at (5,2,0), pointing parallel to the x axis with a base that is 6 high (in y), 4 wide (in z), and with a length 12
#pyramid(pos=[0,0,5],size=(12,6,4),color=color.red)

#ring(pos=vector(1,1,1),axis=vector(0,1,0),radius=0.5, thickness=0.1,color=color.green)
sphere(pos=[0,0,-1],radius=3,material=materials.earth)
