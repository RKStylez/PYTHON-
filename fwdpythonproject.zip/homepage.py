from tkinter import*
import tkinter  as tk
from time import strftime

def donothing():
   filewin = Toplevel(root)
   button = Button(filewin, text="Do nothing button")
   button.pack()
   

root = tk.Tk()
root.geometry("500x700")  
root.configure(bg='skyblue')
root.title('www.Kabaddi Notice.com')
def my_time():
    time_string = strftime('%I:%M:%S %p')
    l1.config(text=time_string)
    l1.after(1000,my_time) 
	
my_font=('times',10,'bold')

l1=tk.Label(root,font=my_font,bg='yellow')
l1.grid(row=1,column=1,padx=422,pady=0)

my_time()

menubar = Menu(root)
filemenu = Menu(menubar, tearoff=0,bg='lightyellow')
filemenu.add_command(label="Login", command=donothing)
filemenu.add_command(label="Your Profile", command=donothing)

filemenu.add_separator()
filemenu.add_command(label="Exit", command=root.quit)
menubar.add_cascade(label="Profile", menu=filemenu)
filemenu = Menu(menubar, tearoff=0,bg='lightyellow')
filemenu.add_command(label="Ariyalur", command=donothing)
filemenu.add_command(label="Chengalpattu", command=donothing)
filemenu.add_command(label="Chennai", command=donothing)
filemenu.add_command(label="Coimbatore")
filemenu.add_command(label="Cuddalore", command=donothing)
filemenu.add_command(label="hsauu", command=donothing)
filemenu.add_command(label="Dharmapuri", command=donothing)
filemenu.add_command(label="Dindigul", command=donothing)
filemenu.add_command(label="Erode", command=donothing)
filemenu.add_command(label="Kallakurichi", command=donothing)
filemenu.add_command(label="Kancheepuram", command=donothing)
filemenu.add_command(label="Karur", command=donothing)
filemenu.add_command(label="Krishnagiri", command=donothing)
filemenu.add_command(label="Madurai", command=donothing)
filemenu.add_command(label="Mayiladuthurai", command=donothing)
filemenu.add_command(label="Nagapattinam", command=donothing)
filemenu.add_command(label="Madurai", command=donothing)
filemenu.add_command(label="Kanyakumari", command=donothing)
filemenu.add_command(label="Namakkal", command=donothing)
filemenu.add_command(label="Perambalur", command=donothing)
filemenu.add_command(label="Pudukottai", command=donothing)
filemenu.add_command(label="Ramanathapuram", command=donothing)
filemenu.add_command(label="Ranipet", command=donothing)
filemenu.add_command(label="Salem", command=donothing)
filemenu.add_command(label="Sivagangai", command=donothing)
filemenu.add_command(label="Tenkasi", command=donothing)
filemenu.add_command(label="Thanjavur", command=donothing)
filemenu.add_command(label="Theni", command=donothing)
filemenu.add_command(label="Thiruvallur", command=donothing)
filemenu.add_command(label="Thiruvarur", command=donothing)
filemenu.add_command(label="Tuticorin", command=donothing)
filemenu.add_command(label="Tiruchirappalli", command=donothing)
filemenu.add_command(label="Thirunelveli", command=donothing)
filemenu.add_command(label="Tirupathur", command=donothing)
filemenu.add_command(label="Tiruppur", command=donothing)
filemenu.add_command(label="Tiruvannamalai", command=donothing)
filemenu.add_command(label="The Nilgiris", command=donothing)
filemenu.add_command(label="Vellore", command=donothing)
filemenu.add_command(label="Viluppuram", command=donothing)
filemenu.add_command(label="Virudhunagar", command=donothing)

filemenu.add_separator()

filemenu.add_command(label="Exit", command=root.quit)
menubar.add_cascade(label="Disdrict", menu=filemenu)
editmenu = Menu(menubar, tearoff=0,bg='lightgreen')
editmenu.add_command(label="Undo", command=donothing)

editmenu.add_separator()

editmenu.add_command(label="Notice", command=donothing)

menubar.add_cascade(label="Upload", menu=editmenu)
helpmenu = Menu(menubar, tearoff=0,bg='lightyellow')
helpmenu.add_command(label="Help Index", command=donothing)
helpmenu.add_command(label="About...", command=donothing)
menubar.add_cascade(label="Help", menu=helpmenu)



root.config(menu=menubar)
root.mainloop()
